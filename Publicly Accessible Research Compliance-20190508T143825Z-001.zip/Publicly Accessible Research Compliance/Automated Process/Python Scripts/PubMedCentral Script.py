
# coding: utf-8

# In[ ]:


import pandas as pd
import urllib.request
import urllib.error
import re
from collections import Counter
from Bio import Entrez


# In[ ]:


Type = input("Enter file type: ")
if Type == 'xlsx':
    File = input("Enter complete file path: ") 
    df = pd.read_excel(File)
else:
    print("Not valid")
 


# In[ ]:


Entrez.email = 'bdalce@terpmail.umd.edu'
Email = input("add email address: ")


# In[ ]:


for index, row in df.iterrows(): #Checks each row in the DOI columnn
    x = row['DOI']
    y = str(x)
    try:
        #url link for DOIs that are available PubMedCentral (JSON format)
        url = 'https://www.ncbi.nlm.nih.gov/pmc/utils/idconv/v1.0/?ids='+str(x)+'&format=json&versions=yes&tool=biopython&email='+str(Email)
        a = urllib.request.urlopen(url).read().decode('utf-8')
        #link for DOIs under embargo or unavailable in PubMedCentral (JSON format)
        url = 'https://www.ncbi.nlm.nih.gov/pmc/utils/idconv/v1.0/?ids='+str(x)+'&format=json&versions=no&tool=biopython&email='+str(Email)
        b = urllib.request.urlopen(url).read().decode('utf-8')
        #search through the json files for 'true' or 'false'
        finderr = re.findall('false', b)
        find = re.findall('true', a)
        #counts how many time 'true' or 'false' appears on the page
        for i in find:
            count = Counter(find)
            if count == Counter({'true': 1}):
                print(index,'YES') #prints 'YES' if true is found once
      
        for i in finderr:
            count = Counter(finderr)
            if count == Counter({'false': 1}):
                print(index, 'NO') #prints 'NO' if false is found once
    except urllib.error.HTTPError as e: 
        if e.code >= 400:
            print(index, 'No')
        

         

